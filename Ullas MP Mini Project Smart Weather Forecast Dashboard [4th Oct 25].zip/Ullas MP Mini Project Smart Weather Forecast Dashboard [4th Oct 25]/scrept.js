// ✅ Your OpenWeatherMap API key
const apiKey = "ee6063438e48ea1b7e50d6bf3ea2b6fb";

// ✅ DOM elements
const cityInput = document.getElementById("city-input");
const searchBtn = document.getElementById("search-btn");
const unitToggle = document.getElementById("unit-toggle");
const forecastContainer = document.getElementById("forecast-container");
const historyList = document.getElementById("history-list");

let currentUnit = localStorage.getItem("unit") || "metric";

// ✅ Fetch current weather by city name
async function getWeather(city) {
  try {
    const weatherUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=${currentUnit}`;
    const res = await fetch(weatherUrl);
    const data = await res.json();

    if (data.cod !== 200) {
      alert("City not found! Please try again.");
      return;
    }

    displayWeather(data);
    getForecast(city);
    saveToHistory(city);
  } catch (error) {
    console.error("Weather fetch error:", error);
  }
}

// ✅ Fetch 5-day forecast
async function getForecast(city) {
  try {
    const forecastUrl = `https://api.openweathermap.org/data/2.5/forecast?q=${city}&appid=${apiKey}&units=${currentUnit}`;
    const res = await fetch(forecastUrl);
    const data = await res.json();

    if (data.cod !== "200") return;

    const forecast = [];
    data.list.forEach((item) => {
      if (item.dt_txt.includes("12:00:00")) forecast.push(item);
    });

    forecastContainer.innerHTML = "";
    forecast.forEach((day) => {
      const date = new Date(day.dt_txt);
      const card = document.createElement("div");
      card.classList.add("forecast-day");
      card.innerHTML = `
        <h4>${date.toLocaleDateString("en-US", { weekday: "short" })}</h4>
        <img src="https://openweathermap.org/img/wn/${day.weather[0].icon}@2x.png" alt="">
        <p>${Math.round(day.main.temp)}°</p>
      `;
      forecastContainer.appendChild(card);
    });
  } catch (error) {
    console.error("Forecast fetch error:", error);
  }
}

// ✅ Display current weather
function displayWeather(data) {
  // 🏙️ Show city name at top
  document.getElementById("city-name").textContent = `${data.name.toUpperCase()} WEATHER`;

  document.getElementById("temperature").textContent =
    Math.round(data.main.temp) + (currentUnit === "metric" ? "°C" : "°F");
  document.getElementById("condition").textContent = data.weather[0].main;
  document.getElementById("humidity").textContent = data.main.humidity;
  document.getElementById("wind").textContent = data.wind.speed;
  document.getElementById("datetime").textContent = new Date().toLocaleString();
  document.getElementById("weather-icon").src =
    `https://openweathermap.org/img/wn/${data.weather[0].icon}@2x.png`;

  // 🎨 Dynamic background by condition
  const condition = data.weather[0].main.toLowerCase();
  if (condition.includes("rain"))
    document.body.style.background = "linear-gradient(135deg, #1b2735, #090a0f)";
  else if (condition.includes("clear"))
    document.body.style.background = "linear-gradient(135deg, #1a2980, #26d0ce)";
  else
    document.body.style.background = "linear-gradient(135deg, #0a0f1c, #1a2133)";
}

// ✅ Save search history
function saveToHistory(city) {
  let history = JSON.parse(localStorage.getItem("history")) || [];
  if (!history.includes(city)) history.push(city);
  localStorage.setItem("history", JSON.stringify(history));
  renderHistory();
}

// ✅ Render search history list
function renderHistory() {
  const history = JSON.parse(localStorage.getItem("history")) || [];
  historyList.innerHTML = "";
  history.forEach((city) => {
    const li = document.createElement("li");
    li.textContent = city;
    li.onclick = () => getWeather(city);
    historyList.appendChild(li);
  });
}

// ✅ Handle temperature unit toggle
unitToggle.checked = currentUnit === "imperial";
unitToggle.onchange = () => {
  currentUnit = unitToggle.checked ? "imperial" : "metric";
  localStorage.setItem("unit", currentUnit);
  const lastCity = JSON.parse(localStorage.getItem("history"))?.slice(-1)[0];
  if (lastCity) getWeather(lastCity);
};

// ✅ Handle city search
searchBtn.onclick = () => {
  const city = cityInput.value.trim();
  if (city) getWeather(city);
  cityInput.value = "";
};

// ✅ On page load — automatically fetch Bengaluru or last searched city
document.addEventListener("DOMContentLoaded", () => {
  renderHistory();
  const lastCity = JSON.parse(localStorage.getItem("history"))?.slice(-1)[0];
  if (lastCity) {
    getWeather(lastCity);
  } else {
    getWeather("Bangalore");
  }
});
