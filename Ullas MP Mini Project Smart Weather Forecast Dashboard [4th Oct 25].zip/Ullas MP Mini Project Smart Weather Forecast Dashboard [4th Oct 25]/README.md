🌦️ Smart Weather Dashboard

A responsive and modern Weather Dashboard web app that displays current weather and a 5-day forecast for any city using the OpenWeatherMap API.

🚀 Features

🌍 Search weather for any city

🌡️ Toggle between Celsius (°C) and Fahrenheit (°F)

📅 View a 5-day forecast with icons

🕒 Shows current date and time

💾 Saves search history in local storage

🎨 Dynamic background changes based on weather condition

💡 Responsive design with modern UI



👨‍💻 Developer

Ullas MP
📧 Developed for learning and practice — enjoy coding!