import React, { useState } from "react";
import Popup from "./Popup";
import "./styles.css";

function App() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPopup, setShowPopup] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setShowPopup(true);
  };

  return (
    <div className="cont">
      <h2>Login Page</h2>

      <form onSubmit={handleSubmit} className="formbox">
        <input
          type="text"
          placeholder="Enter Username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          required
          className="input"
        />

        <input
          type="password"
          placeholder="Enter Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          className="input"
        />

        <button type="submit" className="btn">Submit</button>
      </form>

      {showPopup && (
        <Popup
          message={`Login Successful! Welcome, ${username}`}
          onClose={() => setShowPopup(false)}
        />
      )}
    </div>
  );
}

export default App;
