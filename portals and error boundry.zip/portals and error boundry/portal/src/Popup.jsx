import React from "react";
import ReactDOM from "react-dom";

function Popup({ message, onClose }) {
  return ReactDOM.createPortal(
    <div className="popupoverlay">
      <div className="popupbox">
        <p>{message}</p>
        <button className="closebtn" onClick={onClose}>Close</button>
      </div>
    </div>,
    document.getElementById("portal-root")
  );
}

export default Popup;
