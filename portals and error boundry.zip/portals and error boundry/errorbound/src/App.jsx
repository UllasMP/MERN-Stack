import React from 'react'
import BuggyComponent from "./BuggyComponent";
import ErrorBoundary from './ErrorBoundery';
function App() {
  return (
    <div>
      <ErrorBoundary><BuggyComponent /></ErrorBoundary>
    </div>
  )
}

export default App