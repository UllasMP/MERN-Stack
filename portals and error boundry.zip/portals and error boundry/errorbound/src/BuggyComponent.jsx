import React from 'react';
import ErrorBoundary from './ErrorBoundery';

function MathProblem() {
  const result = divide(8,6);
  return <div>Result: {result}</div>;
}

function divide(a, b) {
  if (b === 0) {
    throw new Error("Division by zero is not allowed");
  }
  return a / b;
}

function BuggyComponent() {
  return (
    <ErrorBoundary>
         <MathProblem />
    </ErrorBoundary>
     
   
  );
}

export default BuggyComponent;
