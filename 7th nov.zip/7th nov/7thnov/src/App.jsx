import { useEffect, useState } from 'react'

import './App.css'

function App() {
  const [img, setImg] = useState([]); //store images
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const loadImages = async () => {
      console.log("🔃Fetching Imag from API....")
      try{
        const res = await fetch("https://picsum.photos/v2/list?page=2&limit=20")
        console.log("API Response Status:", res.status);

        if(!res.ok) throw new Error(`Network Response was not ok: ${res.status}`);

        const data = await res.json();
        console.log("Fetched Data:", data);

        setImg(data);
      }
      catch (err)
      {
        console.error("error Fetching",err);
        setError(err);
      }finally{
        console.log("uff completed");
        setLoading(false);
      }

    
    };
    loadImages();
  },[]);

  if(loading) return <p>Loading Photos....</p>
  if(error) return <p>Failed to load</p>


  return (
    <>
    <h1>Photo Gallery</h1>
    <div>
      {img.map((img) => (
        <div key={img.id}>
          <img src={img.download_url} alt={img.author}/>
        </div>
      ))}
    </div>
    
    
    </>
  )
}

export default App
