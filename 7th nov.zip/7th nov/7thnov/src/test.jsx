import { useEffect, useState } from 'react'

import './App.css'

function test() {
  useEffect(() => {
     fetch("https://jsonplaceholder.typicode.com/posts")
        .then(a => a.json())
        .then(a => console.log(a))
        .catch(e => console.error(e))
      },[])

  return (
    <>
      
    
    </>
  )
}

export default test
