import { useState } from 'react'
import './App.css'
import Modal from './Modal'


function App() {
  const [open, setOpen] = useState(false);

  return (
    <>
      <div style={{backgroundColor:"red" ,padding:"10px"}}>
      <h2>UllasMP</h2>
      </div>

      <div style={{backgroundColor:"black", color:"white"}}>
        <h1>BE student</h1>
      </div>

      <div>
        <button onClick={() => setOpen(true)} style={{backgroundColor:"black", color:"lightgreen"}}>Open</button>
         {open && (<Modal>
           <div style={{color:"black", background:"yellow",padding:"50px"}}>
             This ia a Notification POPUP
              <button onClick={() => setOpen(false)}style={{backgroundColor:"black", color:"lightgreen"}}>CLose</button>
           </div>
           

         </Modal>)}
         
      </div>
    </>
  
    
  )
   
}

export default App
